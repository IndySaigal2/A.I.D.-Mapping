import { Directions, Path, Space, TDirectionInstruction, getMapData, show3dMap } from "@mappedin/mappedin-js";
import "@mappedin/mappedin-js/lib/index.css";

// See Trial API key Terms and Conditions
// https://developer.mappedin.com/web/v6/trial-keys-and-maps/
const options = {
  key: '65ca6d27d53f21f234ae6395',
  secret: '0b25fc24d564c644443663d0b4d083605090d349975d0983fc96e06a5b1934dd',
  mapId: '661aac267c0c4fe5b4cc4a3f'
};

async function init() {
  const mapData = await getMapData(options);
  const mappedinMap = document.getElementById("mappedin-map") as HTMLDivElement;
  const floorSelector = document.createElement("select");
  let feetmeter = true; 
  const meterorfeet = document.createElement("button");
  meterorfeet.textContent = 'Feet';
  mappedinMap.appendChild(meterorfeet);  
  mappedinMap.appendChild(floorSelector);
  const RANKS = ['medium', 'high', 'always-visible'] as const;
  let rank = 0 as number;

  const mapView = await show3dMap(document.getElementById('mappedin-map') as HTMLDivElement, mapData, { initialFloor: 'm_123456789' });
  // Set each space to be interactive.
	mapData.getByType('space').forEach(space => {
    if(space.name.toString() !== 'Hallway'){
      mapView.updateState(space, {
        interactive: true,
      });
    }
	});
  // Set each space to be interactive and its hover color to red.
mapData.getByType('space').forEach(space => {
  if(space.name.toString() !== 'Hallway'){
    mapView.updateState(space, {
      interactive: true,
      hoverColor: 'pink',
    });
  }
});
// Add a label on each space with a name and make the labels interactive.
mapData.getByType('space').forEach(space => {
	if (space.name.toString() !== 'Hallway') {
		mapView.Labels.add(space, space.name, {
			interactive: true,
		});
	}
});
// Add a marker on each space with a name and make the markers interactive.
mapData.getByType('space').forEach(space => {
	if (space.name.toString() !== 'Hallway') {
		mapView.Markers.add(space, `<div>${space.name}</div>`, {
			interactive: true,
		});
	}
});
  // Add each floor to the floor selector.
  mapData.getByType("floor").forEach((floor) => {
    const option = document.createElement("option");
    option.text = floor.name;
    option.value = floor.id;
    floorSelector.appendChild(option);
  });
  mapData.getByType('space').forEach((space) => {
    const room = document.createElement('option');
    room.text = space.name;
    room.value = space.id;
    // firstThing.appendChild(room)
  })


  // Act on the floor-change event to update the level selector.
  mapView.on("floor-change", (event) => {
    // update the level selector
    const id = event?.floor.id;
    if (!id) return;
    floorSelector.value = id;
    console.log("Floor changed to: ", event?.floor.name);
  });

  let startSpace: Space | null = null;
  let path: Path | null = null;
  let destination: Space | null = null;

  // firstThing.addEventListener('change', (e) => {
  //   startSpace = (e.target as HTMLSelectElement)?.value;
  // })

  // Set the initial floor to the current floor.
  floorSelector.value = mapView.currentFloor.id;

  // Act on the floor-selector change event to update the map view.
  floorSelector.addEventListener("change", (e) => {
    mapView.setFloor((e.target as HTMLSelectElement)?.value);
  });
 // Get the spaces for the first and second spaces to navigate to and from.
const firstSpace = mapData.getByType('space').find(s => s.name === 'Cafeteria');
const secondSpace = mapData.getByType('space').find(s => s.name === 'Gymnasium');

// Ensure that the spaces exist.


mapView.on('click', async event => {
	const clickedLocation = event.coordinate;
	const destination = mapData.getByType('space').find(s => s.name === 'Gymnasium');

	// If the destination is found, navigate to it.
	if (destination) {
		//Ensure that directions could be generated (user clicked on a navigable space).
		const directions = mapView.getDirections(clickedLocation, destination);
 
		if (directions) {
			// Navigate from the clicked location to the gymnasium.
			mapView.Navigation.draw(directions);
		}
	}
});
// Set each space to be interactive and its hover color to orange.
mapData.getByType("space").forEach((space) => {
  if(space.name !== 'Hallway') {
  mapView.updateState(space, {
    interactive: true,
    hoverColor: "#777777",
  });
}
});

// Act on the click. If no start space is set, set the start space.
// If a start space is set and no path is set, add the path.
// If a path is set, remove the path and start space.
meterorfeet.addEventListener('click', () => {
  feetmeter = !feetmeter;
  if(feetmeter==true){
  meterorfeet.textContent = 'Feet';
  } else {
  meterorfeet.textContent = 'Meter';
  }
  bypass = true;
});

var bypass = false
mapView.on("click", async (event) => {
  if (!event) return;
  if (!startSpace) {
    startSpace = event.spaces[0];
  } else if ((!path && event.spaces[0])|| bypass == true) {
    bypass = false
    mapView.Markers.removeAll()
    const directions = mapView.getDirections(startSpace, event.spaces[0]);
    destination = event.spaces[0];
    mapView.Markers.removeAll()
    startSpace = destination;
    if (!directions) return;
    mapView.Navigation.draw(directions)
    // Add markers for each direction instruction.
directions.instructions.forEach((instruction: TDirectionInstruction) => {
    if (feetmeter==true) {
      var markerTemplate = `
		    <div class="marker">
			<p>${instruction.action.type} ${instruction.action.bearing ?? ''} and go ${Math.round((instruction.distance)*3.28084)} feet.</p>
		</div>`;
  } else {
    var markerTemplate = `
      <div class="marker">
        <p>${instruction.action.type} ${instruction.action.bearing ?? ''} and go ${Math.round(instruction.distance)} meters.</p>
      </div>`;
    }

	mapView.Markers.add(instruction.coordinate, markerTemplate, {
		rank: "high",
	});
});
  } else{
    //mapView.Paths.removeAll();
    //mapView.Markers.removeAll();
    startSpace = destination;
    path = null;
  }
});
  // SVG image for the label's icon.
  const icon = `<svg width="92" height="92" viewBox="-17 0 92 92" fill="none" xmlns="http://www.w3.org/2000/svg">
	<g clip-path="url(#clip0)">
	<path d="M53.99 28.0973H44.3274C41.8873 28.0973 40.7161 29.1789 40.7161 31.5387V61.1837L21.0491 30.7029C19.6827 28.5889 18.8042 28.1956 16.0714 28.0973H6.5551C4.01742 28.0973 2.84619 29.1789 2.84619 31.5387V87.8299C2.84619 90.1897 4.01742 91.2712 6.5551 91.2712H16.2178C18.7554 91.2712 19.9267 90.1897 19.9267 87.8299V58.3323L39.6912 88.6656C41.1553 90.878 41.9361 91.2712 44.669 91.2712H54.0388C56.5765 91.2712 57.7477 90.1897 57.7477 87.8299V31.5387C57.6501 29.1789 56.4789 28.0973 53.99 28.0973Z" fill="white"/>
	<path d="M11.3863 21.7061C17.2618 21.7061 22.025 16.9078 22.025 10.9887C22.025 5.06961 17.2618 0.27124 11.3863 0.27124C5.51067 0.27124 0.747559 5.06961 0.747559 10.9887C0.747559 16.9078 5.51067 21.7061 11.3863 21.7061Z" fill="white"/>
	</g>
	<defs>
	<clipPath id="clip0">
	<rect width="57" height="91" fill="white" transform="translate(0.747559 0.27124)"/>
	</clipPath>
	</defs>
	</svg>`;

  const colors = ["blue", "purple", "green", "orange", "tomato", "gray"];

  // Label all spaces with their space name and add styling using a custom appearance and SVG icon.
  mapData.getByType("space").forEach((space, index) => {
    if (space.name) {
      const color = colors[index % colors.length];

      mapView.Labels.add(space, space.name, {
        appearance: {
          marker: {
            foregroundColor: {
              active: color,
              inactive: color,
            },
            icon: icon,
          },
          text: {
            foregroundColor: color,
          },
        },
      });
    }
  });
}

init();